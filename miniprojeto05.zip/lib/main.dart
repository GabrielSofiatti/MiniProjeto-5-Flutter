import 'package:flutter/material.dart';
import 'package:listatarefas/home.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}
